function[number]=analyze_surface_version

%           analyze_version  Returns analyze_surface version number.
%
%   _________________________________________________________________
%   This is part of the analyze_surface toolbox, (C) 2009 A. Klocker
%   type 'help analyze_surface' for more information 
%   type 'analyze_surface_license' for license details
%   type 'analyze_surface_version' for version details
%
 
number='analyze_surface by A. Klocker version 1.00';