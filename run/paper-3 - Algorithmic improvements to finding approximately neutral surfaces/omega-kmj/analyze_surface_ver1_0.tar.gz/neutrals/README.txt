The matlab files in this folder have been written by David R Jackett. 

These files are used to take a cast of hydrographic data {s,t,p} that 
has been labelled with gamma and find the salinities, conservative 
temperatures and pressures of specified neutral density surfaces.
